
# Usage Guide

## 1. Streamlit Web UI
1. Activate your virtual environment.
2. Run `streamlit run app_streamlit.py`.
3. Use the left sidebar to:
   - Switch **Engine Mode** between *Rule-based* and *LLM (adapter)*.
   - Change bot name and temperature.
   - Clear conversation.
4. Type your message at the bottom and press **Enter**.

## 2. ttkbootstrap Desktop UI
1. Run `python app_ttkbootstrap.py`.
2. Choose theme from the top right dropdown (optional).
3. Type in the entry box and press **Send**.
4. Use **File → New chat** to clear history.

## 3. Configure LLM (Optional)
1. Copy `config.example.yaml` to `config.yaml`.
2. Edit `llm.provider`, `llm.model`, and set an environment variable for your API key (e.g., `OPENAI_API_KEY`).
3. In the Streamlit app sidebar, choose **LLM (adapter)**.

## 4. Add FAQs / Knowledge
- Edit `data/faq.yaml` to include domain-specific Q&A. The rule-based engine performs a simple keyword match to answer from this file.

## 5. Troubleshooting
- If Streamlit chat UI doesn't render, upgrade Streamlit to >=1.27.
- If fonts look off in the desktop app, try a different ttkbootstrap theme.
- If LLM adapter not configured, app will fall back to rule-based mode.
