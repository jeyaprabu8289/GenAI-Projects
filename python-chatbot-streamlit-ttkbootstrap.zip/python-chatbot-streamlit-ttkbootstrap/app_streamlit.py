
import os
import yaml
import streamlit as st
from backend.chat_engine import ChatEngine
from backend.llm_adapter import LLMAdapter

st.set_page_config(page_title="Chatbot (Streamlit)", page_icon="🤖", layout="wide")

# --- Load config ---

def load_config():
    path = "config.yaml"
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    with open("config.example.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

cfg = load_config()
app_name = cfg.get("app", {}).get("name", "Chatbot")

# --- Session state ---
if "engine" not in st.session_state:
    llm_cfg = cfg.get("llm", {})
    st.session_state.engine = ChatEngine(
        mode=cfg.get("engine", {}).get("mode", "rule_based"),
        temperature=cfg.get("engine", {}).get("temperature", 0.2),
        llm_adapter=LLMAdapter(
            provider=llm_cfg.get("provider", ""),
            model=llm_cfg.get("model", ""),
            api_key_env=llm_cfg.get("api_key_env", ""),
        ),
        faq_path="data/faq.yaml",
    )

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": f"Hi! I'm {app_name}. Ask me about the app or anything basic."}
    ]

# --- Sidebar ---
st.sidebar.header("⚙️ Settings")
mode = st.sidebar.radio("Engine Mode", ["rule_based", "llm"], index=0)
st.session_state.engine.mode = mode

st.session_state.engine.temperature = st.sidebar.slider("Temperature (LLM)", 0.0, 1.0, value=cfg.get("engine", {}).get("temperature", 0.2), step=0.05)

if st.sidebar.button("Clear Conversation"):
    st.session_state.messages = []
    st.session_state.engine.reset()

st.sidebar.markdown("---")
st.sidebar.write("FAQ file:", st.session_state.engine.faq_path)

st.title(f"🤖 {app_name} — Streamlit UI")

# --- Chat display ---
for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

# --- Input ---
prompt = st.chat_input("Type your message")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            reply = st.session_state.engine.generate_reply(prompt)
            st.session_state.messages.append({"role": "assistant", "content": reply})
            st.markdown(reply)
