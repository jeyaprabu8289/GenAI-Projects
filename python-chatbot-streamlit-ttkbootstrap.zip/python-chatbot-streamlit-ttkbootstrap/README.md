# Chatbot App (Streamlit & ttkbootstrap)

A simple, local-first chatbot application with **two frontends**:

- **Streamlit web UI** (`app_streamlit.py`) – run in your browser.
- **ttkbootstrap desktop UI** (`app_ttkbootstrap.py`) – a desktop app using Tkinter with modern theming.

The app uses a lightweight, rule-based chatbot engine by default (no internet or API key required). You can also extend it to use external LLMs by adding your own adapter.

---

## ✨ Features
- Two front-ends out of the box: Streamlit & ttkbootstrap (Tkinter).
- Local rule-based engine with small-talk and FAQ matching.
- Simple keyword retrieval over a local FAQ file (`data/faq.yaml`).
- In-memory conversation history with clear/reset.
- Extensible architecture: plug in your own LLM provider in `backend/llm_adapter.py`.

---

## 🧱 Project Structure
```
python-chatbot-streamlit-ttkbootstrap/
├── app_streamlit.py
├── app_ttkbootstrap.py
├── requirements.txt
├── README.md
├── LICENSE
├── config.example.yaml
├── backend/
│   ├── chat_engine.py
│   └── llm_adapter.py
├── data/
│   └── faq.yaml
├── assets/
│   └── logo.txt
└── docs/
    └── USAGE.md
```

---

## 🚀 Quickstart

### 1) Prerequisites
- Python 3.9+ recommended
- macOS, Windows, or Linux

### 2) Create & activate a virtual environment
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
```

### 3) Install dependencies
```bash
pip install -r requirements.txt
```

### 4) Run the Streamlit web app
```bash
streamlit run app_streamlit.py
```
Then open the URL Streamlit prints (usually http://localhost:8501).

### 5) Run the ttkbootstrap desktop app
```bash
python app_ttkbootstrap.py
```

---

## ⚙️ Configuration (Optional)
Copy `config.example.yaml` to `config.yaml` (same folder as the apps) and adjust values.

---

## 🧩 Extend with an LLM
Use `backend/llm_adapter.py` as a starting point to integrate your favorite provider. The Streamlit sidebar exposes a toggle to switch between **Rule-based** and **LLM (adapter)** modes. If no provider is configured, it will gracefully fall back to the rule-based engine.

---

## 📄 License
MIT — see `LICENSE`.

---

## 🙌 Acknowledgments
- Built with [Streamlit](https://streamlit.io/) and [ttkbootstrap](https://github.com/israel-dryer/ttkbootstrap).
