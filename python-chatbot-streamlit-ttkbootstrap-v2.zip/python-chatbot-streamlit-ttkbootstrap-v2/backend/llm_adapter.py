from __future__ import annotations
import os
from typing import Dict, List, Optional

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

class LLMAdapter:
    def __init__(self, provider: str = "", model: str = "", api_key_env: str = ""):
        self.provider = provider
        self.model = model
        self.api_key_env = api_key_env
        self.api_key = os.environ.get(api_key_env) if api_key_env else None
        self._client = None
        if self.provider == "openai" and OpenAI is not None and self.api_key:
            self._client = OpenAI(api_key=self.api_key)

    def is_configured(self) -> bool:
        if self.provider == "openai":
            return bool(self._client and self.model)
        return False

    def generate(self, prompt: str, history: List[Dict[str, str]] | None = None, temperature: float = 0.2, context: Optional[str] = None) -> str:
        if not self.is_configured():
            return "[LLM adapter not configured. Falling back to rule-based mode.]"
        if self.provider == "openai":
            messages = []
            if context:
                messages.append({"role": "system", "content": f"Use the following context if relevant to answer the user succinctly.\n\n{context}"})
            if history:
                for m in history:
                    role = m.get("role", "user")
                    content = m.get("content", "")
                    if role in {"user", "assistant", "system"}:
                        messages.append({"role": role, "content": content})
            if not messages or messages[-1].get("role") != "user":
                messages.append({"role": "user", "content": prompt})
            try:
                resp = self._client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                )
                return resp.choices[0].message.content or ""
            except Exception as e:
                return f"[OpenAI error: {e}]"
        return "[Unsupported provider]"

    def transcribe(self, audio_bytes: bytes, filename: str = "audio.wav", response_format: str = "text") -> str:
        """Transcribe audio using OpenAI Whisper (if configured)."""
        if not self.is_configured() or self.provider != "openai":
            return "[Transcription unavailable: LLM not configured]"
        try:
            from io import BytesIO
            buf = BytesIO(audio_bytes)
            buf.name = filename
            tr = self._client.audio.transcriptions.create(
                model="whisper-1",
                file=buf,
                response_format=response_format,
            )
            return tr if isinstance(tr, str) else getattr(tr, "text", str(tr))
        except Exception as e:
            return f"[Transcription error: {e}]"
