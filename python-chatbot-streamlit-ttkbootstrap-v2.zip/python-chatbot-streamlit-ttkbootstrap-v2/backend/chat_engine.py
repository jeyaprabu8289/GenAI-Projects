from __future__ import annotations
import yaml
from dataclasses import dataclass, field
from typing import Dict, List, Optional

def _normalize(text: str) -> str:
    import re as _re
    return _re.sub(r"\s+", " ", text.strip().lower())

SMALL_TALK = {
    "hello": "Hello! How can I help you today?",
    "hi": "Hi there! What can I do for you?",
    "hey": "Hey! How's it going?",
    "thanks": "You're welcome!",
    "thank you": "You're welcome!",
}

HELP_TEXT = (
    "I'm a simple chatbot. Try asking me about the app, how to run it, or say hello. "
    "In Streamlit, you can switch engines from the sidebar."
)

@dataclass
class ChatEngine:
    mode: str = "rule_based"
    temperature: float = 0.2
    llm_adapter: Optional[object] = None
    faq_path: str = "data/faq.yaml"
    memory: List[Dict[str, str]] = field(default_factory=list)

    def load_faq(self) -> List[Dict[str, str]]:
        try:
            with open(self.faq_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            return data.get("faqs", [])
        except FileNotFoundError:
            return []

    def _faq_answer(self, user_text: str) -> Optional[str]:
        faqs = self.load_faq()
        u = _normalize(user_text)
        best_match = None
        best_score = 0
        for item in faqs:
            q = _normalize(item.get("q", ""))
            tokens_u = set(u.split())
            tokens_q = set(q.split())
            score = len(tokens_u & tokens_q) / max(1, len(tokens_q))
            if score > best_score:
                best_score = score
                best_match = item
        if best_match and best_score >= 0.4:
            return best_match.get("a")
        return None

    def _rule_based(self, user_text: str, context: Optional[str] = None) -> str:
        n = _normalize(user_text)
        for k, v in SMALL_TALK.items():
            if k in n:
                return v
        if any(w in n for w in ["help", "what can you do", "how to use"]):
            return HELP_TEXT
        ans = self._faq_answer(user_text)
        if ans:
            return ans
        if context:
            return f"I didn't find an FAQ answer. Based on your documents, here's something relevant:\n\n{context[:800]}"
        if self.memory:
            last_user = next((m["content"] for m in reversed(self.memory) if m["role"] == "user"), "")
            if last_user and last_user != user_text:
                return f"I didn't find an exact answer. Previously you asked: '{last_user}'. Can you clarify what you need?"
        return "I'm not sure yet, but I can try if you rephrase or add more details."

    def generate_reply(self, user_text: str, context: Optional[str] = None) -> str:
        self.memory.append({"role": "user", "content": user_text})
        if self.mode == "llm" and self.llm_adapter and self.llm_adapter.is_configured():
            reply = self.llm_adapter.generate(user_text, self.memory, temperature=self.temperature, context=context)
        else:
            reply = self._rule_based(user_text, context=context)
        self.memory.append({"role": "assistant", "content": reply})
        return reply

    def export_messages(self) -> List[Dict[str, str]]:
        return list(self.memory)

    def import_messages(self, messages: List[Dict[str, str]]):
        self.memory.clear()
        for m in messages:
            if isinstance(m, dict) and m.get("role") in {"user", "assistant", "system"}:
                self.memory.append({"role": m["role"], "content": m.get("content", "")})

    def reset(self):
        self.memory.clear()
