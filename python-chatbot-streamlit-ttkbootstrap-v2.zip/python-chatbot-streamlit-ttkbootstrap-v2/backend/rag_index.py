from __future__ import annotations
import os, re, json, math
from typing import List, Dict

try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None
try:
    import docx
except Exception:
    docx = None

_WORD_RE = re.compile(r"[\w-]+", re.UNICODE)

def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in _WORD_RE.findall(text)]

def load_text_from_file(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in [".txt", ".md"]:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    if ext == ".pdf":
        if fitz is None:
            raise RuntimeError("PyMuPDF (fitz) not installed; cannot parse PDF")
        text = []
        with fitz.open(path) as doc:
            for page in doc:
                text.append(page.get_text())
        return "\n".join(text)
    if ext in [".docx"]:
        if docx is None:
            raise RuntimeError("python-docx not installed; cannot parse DOCX")
        d = docx.Document(path)
        parts = [p.text for p in d.paragraphs]
        for tbl in d.tables:
            for row in tbl.rows:
                parts.append("\t".join(cell.text for cell in row.cells))
        return "\n".join(parts)
    raise ValueError(f"Unsupported file type: {ext}")

def chunk_text(text: str, chunk_tokens: int = 180, overlap: int = 40) -> List[str]:
    tokens = _tokenize(text)
    chunks = []
    i = 0
    while i < len(tokens):
        chunk = tokens[i:i+chunk_tokens]
        if not chunk:
            break
        chunks.append(" ".join(chunk))
        i += max(1, chunk_tokens - overlap)
    return chunks

class BM25Index:
    def __init__(self):
        self.docs: List[Dict] = []
        self.df: Dict[str, int] = {}
        self.avg_len: float = 0.0
        self.k1 = 1.5
        self.b = 0.75

    def add_document(self, text: str, source: str, chunk_id: int):
        tokens = _tokenize(text)
        doc = {"id": len(self.docs), "text": text, "tokens": tokens, "source": source, "chunk_id": chunk_id, "len": len(tokens)}
        self.docs.append(doc)

    def finalize(self):
        N = len(self.docs)
        if N == 0:
            self.df = {}
            self.avg_len = 0.0
            return
        df = {}
        total_len = 0
        for d in self.docs:
            total_len += d["len"]
            seen = set(d["tokens"])
            for t in seen:
                df[t] = df.get(t, 0) + 1
        self.df = df
        self.avg_len = total_len / N

    def _idf(self, term: str) -> float:
        N = len(self.docs)
        df = self.df.get(term, 0)
        return math.log((N - df + 0.5) / (df + 0.5) + 1.0)

    def search(self, query: str, top_k: int = 5) -> List[Dict]:
        if not self.docs:
            return []
        q_tokens = _tokenize(query)
        scores = []
        for d in self.docs:
            score = 0.0
            tf = {}
            for t in d["tokens"]:
                tf[t] = tf.get(t, 0) + 1
            for qt in q_tokens:
                if qt not in tf:
                    continue
                idf = self._idf(qt)
                denom = tf[qt] + self.k1 * (1 - self.b + self.b * (d["len"] / max(1e-9, self.avg_len)))
                score += idf * (tf[qt] * (self.k1 + 1)) / max(1e-9, denom)
            if score > 0:
                scores.append((score, d))
        scores.sort(key=lambda x: x[0], reverse=True)
        return [{"score": s, "text": d["text"], "source": d["source"], "chunk_id": d["chunk_id"]} for s, d in scores[:top_k]]

    def to_json(self) -> Dict:
        return {"docs": self.docs, "df": self.df, "avg_len": self.avg_len, "k1": self.k1, "b": self.b}

    @classmethod
    def from_json(cls, data: Dict) -> "BM25Index":
        idx = cls()
        idx.docs = data.get("docs", [])
        idx.df = data.get("df", {})
        idx.avg_len = data.get("avg_len", 0.0)
        idx.k1 = data.get("k1", 1.5)
        idx.b = data.get("b", 0.75)
        return idx

def build_index_from_files(file_paths: List[str]) -> BM25Index:
    idx = BM25Index()
    for fp in file_paths:
        try:
            raw = load_text_from_file(fp)
        except Exception:
            continue
        chunks = chunk_text(raw)
        for i, ch in enumerate(chunks):
            idx.add_document(ch, source=os.path.basename(fp), chunk_id=i)
    idx.finalize()
    return idx

def save_index_json(idx: BM25Index, path: str):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(idx.to_json(), f)

def load_index_json(path: str) -> BM25Index:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return BM25Index.from_json(data)
