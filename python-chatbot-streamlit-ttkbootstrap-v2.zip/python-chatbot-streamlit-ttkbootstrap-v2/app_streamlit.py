import os
import io
import yaml
import streamlit as st
from backend.chat_engine import ChatEngine
from backend.llm_adapter import LLMAdapter
from backend.rag_index import build_index_from_files, save_index_json, load_index_json

st.set_page_config(page_title="Chatbot (Streamlit)", page_icon="🤖", layout="wide")

BASE_DIR = os.path.dirname(__file__)
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
INDEX_DIR = os.path.join(BASE_DIR, "indexes")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(INDEX_DIR, exist_ok=True)
INDEX_PATH = os.path.join(INDEX_DIR, "bm25_index.json")

def load_config():
    path = os.path.join(BASE_DIR, "config.yaml")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    with open(os.path.join(BASE_DIR, "config.example.yaml"), "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

cfg = load_config()
app_name = cfg.get("app", {}).get("name", "Chatbot")

if "engine" not in st.session_state:
    llm_cfg = cfg.get("llm", {})
    st.session_state.engine = ChatEngine(
        mode=cfg.get("engine", {}).get("mode", "rule_based"),
        temperature=cfg.get("engine", {}).get("temperature", 0.2),
        llm_adapter=LLMAdapter(
            provider=llm_cfg.get("provider", ""),
            model=llm_cfg.get("model", ""),
            api_key_env=llm_cfg.get("api_key_env", ""),
        ),
        faq_path=os.path.join(BASE_DIR, "data", "faq.yaml"),
    )

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": f"Hi! I'm {app_name}. Ask me about the app or anything basic."}
    ]

if "index_loaded" not in st.session_state:
    st.session_state.index_loaded = False
    if os.path.exists(INDEX_PATH):
        try:
            st.session_state.index = load_index_json(INDEX_PATH)
            st.session_state.index_loaded = True
        except Exception:
            st.session_state.index = None
    else:
        st.session_state.index = None

st.sidebar.header("⚙️ Settings")
mode = st.sidebar.radio("Engine Mode", ["rule_based", "llm"], index=0)
st.session_state.engine.mode = mode

st.session_state.engine.temperature = st.sidebar.slider("Temperature (LLM)", 0.0, 1.0, value=cfg.get("engine", {}).get("temperature", 0.2), step=0.05)

if st.sidebar.button("Clear Conversation"):
    st.session_state.messages = []
    st.session_state.engine.reset()

st.sidebar.markdown("---")

st.sidebar.subheader("💾 Chat History")
col_a, col_b = st.sidebar.columns(2)
with col_a:
    if st.button("Save JSON"):
        import json as _json
        buf = io.BytesIO()
        data = {"messages": st.session_state.engine.export_messages()}
        buf.write(_json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"))
        st.download_button("Download history.json", data=buf.getvalue(), file_name="history.json", mime="application/json")
with col_b:
    up_hist = st.file_uploader("Load JSON", type=["json"], label_visibility="collapsed")
    if up_hist is not None:
        try:
            import json as _json
            content = _json.loads(up_hist.read().decode("utf-8"))
            msgs = content.get("messages", [])
            st.session_state.engine.import_messages(msgs)
            st.session_state.messages = list(msgs)
            st.success("Conversation loaded from JSON.")
        except Exception as e:
            st.error(f"Failed to load: {e}")

st.sidebar.markdown("---")

st.sidebar.subheader("📚 Documents & RAG")
rag_toggle = st.sidebar.checkbox("Use RAG in chat", value=True)
rag_top_k = st.sidebar.slider("Top-k passages", 1, 10, 4)

doc_files = st.sidebar.file_uploader("Upload docs (PDF, DOCX, TXT)", type=["pdf", "docx", "txt", "md"], accept_multiple_files=True)
if st.sidebar.button("Add to Index") and doc_files:
    saved_paths = []
    for uf in doc_files:
        dest = os.path.join(UPLOAD_DIR, uf.name)
        with open(dest, "wb") as f:
            f.write(uf.getbuffer())
        saved_paths.append(dest)
    all_paths = [os.path.join(UPLOAD_DIR, p) for p in os.listdir(UPLOAD_DIR) if os.path.isfile(os.path.join(UPLOAD_DIR, p))]
    idx = build_index_from_files(all_paths)
    save_index_json(idx, INDEX_PATH)
    st.session_state.index = idx
    st.session_state.index_loaded = True
    st.sidebar.success(f"Indexed {len(all_paths)} file(s).")

if st.session_state.index_loaded:
    st.sidebar.info("Index ready ✅")
else:
    st.sidebar.warning("No index yet.")

st.sidebar.markdown("---")

st.sidebar.subheader("🎙️ Speech → Text")
audio_file = st.sidebar.file_uploader("Upload audio (mp3/wav/m4a)", type=["mp3", "wav", "m4a", "mp4", "mpga"])
if st.sidebar.button("Transcribe") and audio_file is not None:
    audio_bytes = audio_file.getvalue()
    text = st.session_state.engine.llm_adapter.transcribe(audio_bytes, filename=audio_file.name)
    if text.startswith("[") and "error" in text.lower():
        st.sidebar.error(text)
    else:
        st.sidebar.success("Transcribed. Inserted below.")
        st.session_state.transcribed_text = text

st.title(f"🤖 {app_name} — Streamlit UI")

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

with st.expander("🔎 Quick document search"):
    q = st.text_input("Search your indexed documents", key="rag_query")
    if q and st.session_state.index_loaded:
        res = st.session_state.index.search(q, top_k=rag_top_k)
        if not res:
            st.write("No matches.")
        else:
            for i, r in enumerate(res, 1):
                st.markdown(f"**{i}. {r['source']}** (score {r['score']:.3f})\n\n> {r['text'][:400]}…")

def build_context_from_rag(query: str, top_k: int = 4) -> str:
    if not st.session_state.index_loaded:
        return ""
    res = st.session_state.index.search(query, top_k=top_k)
    ctx_parts = []
    for r in res:
        ctx_parts.append(f"[source: {r['source']} | score {r['score']:.3f}]\n{r['text']}")
    return "\n\n".join(ctx_parts)

prefill = st.session_state.pop("transcribed_text", None)
prompt = st.chat_input("Type your message", max_chars=4000) if prefill is None else prefill
if prefill is not None:
    st.info("Transcribed text inserted. Press Enter to send or edit it.")

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            context = build_context_from_rag(prompt, top_k=rag_top_k) if rag_toggle else None
            reply = st.session_state.engine.generate_reply(prompt, context=context)
            st.session_state.messages.append({"role": "assistant", "content": reply})
            st.markdown(reply)
