# Chatbot App (Streamlit & ttkbootstrap) — v2

This version adds **message persistence (JSON save/load)**, **Streamlit file uploads with a local BM25 RAG index**, **OpenAI chat integration**, and **Whisper speech-to-text**.

## Features
- Streamlit web UI and ttkbootstrap desktop UI.
- Rule-based local engine + optional OpenAI LLM.
- Chat history save/load as JSON.
- Upload PDFs/DOCX/TXT → build RAG (BM25) index → retrieve top passages.
- Speech-to-text (upload audio; OpenAI Whisper).

See `docs/USAGE.md` for steps.
