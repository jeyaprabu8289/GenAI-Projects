# Usage Guide (v2)

This version adds:
- **Message persistence**: save / load chat as JSON (Streamlit sidebar and ttkbootstrap File menu)
- **Document RAG**: upload PDFs/DOCX/TXT in Streamlit → build a local BM25 index → retrieve top-k passages
- **OpenAI integration**: set provider="openai" in `config.yaml` to enable LLM chat & Whisper STT
- **Speech-to-Text**: upload audio in Streamlit sidebar, transcribe via OpenAI Whisper (`whisper-1`)

---

## 1) Configure OpenAI (optional, for LLM & STT)
1. Copy `config.example.yaml` → `config.yaml`.
2. Set:
   ```yaml
   llm:
     provider: "openai"
     model: "gpt-4o-mini"   # or your preferred model
     api_key_env: "OPENAI_API_KEY"
   ```
3. Export your key in the shell before running:
   - PowerShell (Windows): `setx OPENAI_API_KEY "<your key>"`
   - macOS/Linux: `export OPENAI_API_KEY="<your key>"`

> The official OpenAI Python SDK highlights the **Responses API** as the primary surface but notes **Chat Completions** is still supported indefinitely; this app uses Chat Completions for wide compatibility. Whisper STT uses `client.audio.transcriptions.create` with `model="whisper-1"`.

## 2) Run the Streamlit web app
```bash
streamlit run app_streamlit.py
```

### 2.1 Save / Load chat history
- **Save JSON**: Sidebar → *Save JSON* → download `history.json`.
- **Load JSON**: Sidebar → *Load JSON* → pick a JSON file to restore.

### 2.2 Upload documents & build RAG index
1. Sidebar → **Upload docs** (PDF, DOCX, TXT, MD) and click **Add to Index**.
2. Toggle **Use RAG in chat** to stuff top-*k* passages into the LLM context.
3. Use **Quick document search** to preview matches.

### 2.3 Speech → Text
1. Sidebar → **Upload audio** (`.mp3`, `.wav`, `.m4a`, `.mp4`, `.mpga`).
2. Click **Transcribe**. If configured, the text is inserted into the chat input.

## 3) ttkbootstrap desktop app
```bash
python app_ttkbootstrap.py
```
- **File → Save chat (JSON)...** and **Load chat (JSON)...**

## 4) Notes
- RAG index is local BM25 (no embeddings). It chunks to ~180 tokens with 40-token overlap.
- PDFs need **PyMuPDF**; DOCX needs **python-docx**.
- If OpenAI is not configured, LLM mode and STT return a friendly fallback message.
