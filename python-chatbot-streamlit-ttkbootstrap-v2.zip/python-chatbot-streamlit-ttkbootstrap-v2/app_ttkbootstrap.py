import os
import yaml
import json
import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox
import ttkbootstrap as tb
from ttkbootstrap.constants import *
from backend.chat_engine import ChatEngine
from backend.llm_adapter import LLMAdapter

BASE_DIR = os.path.dirname(__file__)

def load_config():
    path = os.path.join(BASE_DIR, "config.yaml")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    with open(os.path.join(BASE_DIR, "config.example.yaml"), "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

cfg = load_config()
app_name = cfg.get("app", {}).get("name", "Chatbot")
initial_theme = cfg.get("app", {}).get("theme", "darkly")

class ChatApp(tb.Window):
    def __init__(self):
        super().__init__(title=f"{app_name} — ttkbootstrap UI", themename=initial_theme)
        self.geometry("860x600")

        llm_cfg = cfg.get("llm", {})
        self.engine = ChatEngine(
            mode=cfg.get("engine", {}).get("mode", "rule_based"),
            temperature=cfg.get("engine", {}).get("temperature", 0.2),
            llm_adapter=LLMAdapter(
                provider=llm_cfg.get("provider", ""),
                model=llm_cfg.get("model", ""),
                api_key_env=llm_cfg.get("api_key_env", ""),
            ),
            faq_path=os.path.join(BASE_DIR, "data", "faq.yaml"),
        )

        self._build_menu()
        self._build_layout()
        self._bot_say(f"Hi! I'm {app_name}. Ask me about the app or anything basic.")

    def _build_menu(self):
        menubar = tk.Menu(self)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New chat", command=self._clear_chat)
        file_menu.add_separator()
        file_menu.add_command(label="Save chat (TXT)...", command=self._save_chat_txt)
        file_menu.add_command(label="Save chat (JSON)...", command=self._save_chat_json)
        file_menu.add_command(label="Load chat (JSON)...", command=self._load_chat_json)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.destroy)
        menubar.add_cascade(label="File", menu=file_menu)

        engine_menu = tk.Menu(menubar, tearoff=0)
        engine_menu.add_command(label="Rule-based", command=lambda: self._set_mode("rule_based"))
        engine_menu.add_command(label="LLM (adapter)", command=lambda: self._set_mode("llm"))
        menubar.add_cascade(label="Engine", menu=engine_menu)

        self.config(menu=menubar)

    def _build_layout(self):
        topbar = tb.Frame(self)
        topbar.pack(side=TOP, fill=X, padx=10, pady=5)

        tb.Label(topbar, text=app_name, font=("Segoe UI", 14, "bold")).pack(side=LEFT)

        tb.Label(topbar, text="Theme:").pack(side=RIGHT, padx=5)
        self.theme_combo = tb.Combobox(topbar, values=sorted(self.style.theme_names()))
        self.theme_combo.set(initial_theme)
        self.theme_combo.bind("<<ComboboxSelected>>", self._on_theme_change)
        self.theme_combo.pack(side=RIGHT)

        self.chat_box = scrolledtext.ScrolledText(self, state="disabled", wrap=tk.WORD, font=("Segoe UI", 11))
        self.chat_box.pack(fill=BOTH, expand=YES, padx=10, pady=(0, 10))

        bottom = tb.Frame(self)
        bottom.pack(side=BOTTOM, fill=X, padx=10, pady=10)
        self.entry = tb.Entry(bottom)
        self.entry.pack(side=LEFT, fill=X, expand=YES)
        self.entry.bind("<Return>", lambda e: self._on_send())
        tb.Button(bottom, text="Send", bootstyle=PRIMARY, command=self._on_send).pack(side=LEFT, padx=5)

    def _append(self, who: str, text: str):
        self.chat_box.configure(state="normal")
        self.chat_box.insert(tk.END, f"{who}: {text}\n")
        self.chat_box.configure(state="disabled")
        self.chat_box.see(tk.END)

    def _bot_say(self, text: str):
        self._append("🤖", text)

    def _user_say(self, text: str):
        self._append("🧑", text)

    def _on_send(self):
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, tk.END)
        self._user_say(text)
        reply = self.engine.generate_reply(text)
        self._bot_say(reply)

    def _on_theme_change(self, event=None):
        theme = self.theme_combo.get()
        self.style.theme_use(theme)

    def _set_mode(self, mode: str):
        self.engine.mode = mode
        messagebox.showinfo("Engine", f"Switched engine to: {mode}")

    def _clear_chat(self):
        self.chat_box.configure(state="normal")
        self.chat_box.delete(1.0, tk.END)
        self.chat_box.configure(state="disabled")
        self.engine.reset()
        self._bot_say("New chat started.")

    def _save_chat_txt(self):
        content = self.chat_box.get(1.0, tk.END)
        path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text", "*.txt")])
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        messagebox.showinfo("Saved", f"Chat saved to {path}")

    def _save_chat_json(self):
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON", "*.json")])
        if not path:
            return
        data = self.engine.export_messages()
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"messages": data}, f, ensure_ascii=False, indent=2)
        messagebox.showinfo("Saved", f"Chat JSON saved to {path}")

    def _load_chat_json(self):
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            msgs = data.get("messages", [])
            self.engine.import_messages(msgs)
            self.chat_box.configure(state="normal")
            self.chat_box.delete(1.0, tk.END)
            for m in msgs:
                who = "🤖" if m.get("role") == "assistant" else ("🧑" if m.get("role") == "user" else "📝")
                self.chat_box.insert(tk.END, f"{who}: {m.get('content','')}\n")
            self.chat_box.configure(state="disabled")
            messagebox.showinfo("Loaded", "Conversation loaded from JSON.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    app = ChatApp()
    app.mainloop()
