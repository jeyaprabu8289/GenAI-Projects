
# 📄 RAG Vector DB App (Streamlit + Chroma + OpenAI)

An end-to-end local app to upload documents (PDF / DOCX / Images), build a **RAG** index on an **open-source vector DB (Chroma)**, and chat with your data using an **OpenAI** model. Includes a **Bootstrap-styled Streamlit UI**, **login with OTP**, a **summary dashboard**, and a **filterable table view**.

https://github.com/ (you can paste these files into a new repo)

---

## ✨ Features
- **Login with OTP** (console or SMTP email)
- **Streamlit + Bootstrap**-styled UI
- **Open-source Vector DB**: [ChromaDB](https://www.trychroma.com/)
- **Document types**: PDF, DOCX, Images (JPG/PNG) with OCR via Tesseract
- **RAG** pipeline: chunking → embeddings → Chroma index → retrieval → LLM answer
- **Dashboard**: document counts, charts, and **filterable table** (AgGrid)
- **Chat** with your docs; sources shown for transparency
- **Local persistence** of the vector store

---

## 🧰 Prerequisites
- Python 3.9–3.11 (recommended)
- An OpenAI API key
- For image OCR: [Tesseract OCR](https://tesseract-ocr.github.io/)
  - **macOS**: `brew install tesseract`
  - **Ubuntu/Debian**: `sudo apt-get update && sudo apt-get install -y tesseract-ocr`
  - **Windows**: Install from: https://github.com/UB-Mannheim/tesseract/wiki

---

## 🚀 Quickstart

```bash
# 1) Create & activate a virtual environment
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Configure environment
cp .env.example .env
# Edit .env and set OPENAI_API_KEY; OTP_MODE=console is fine for local dev

# 4) Run the app
streamlit run app.py
```

Open the URL printed by Streamlit (usually http://localhost:8501).

---

## 🔐 OTP Login
- Enter your email and click **Send OTP**.
- If `OTP_MODE=console`, the OTP is printed in the server logs.
- If `OTP_MODE=smtp`, the app will email the OTP using your SMTP settings.

> Optional: set `ALLOWED_USERS` (comma-separated list) to restrict who can log in.

---

## 📤 Uploading Documents
- Supported: **PDF**, **DOCX**, **JPG**, **JPEG**, **PNG**
- Uploaded files are stored under `UPLOAD_DIR` (default: `./data/uploads`).
- After upload, the app extracts text, chunks it, generates **OpenAI embeddings**, and writes vectors to a persistent **Chroma** collection.

> ⚠️ If Tesseract is not installed, image OCR will be skipped with a warning.

---

## 📊 Dashboard & Table View
- See key metrics (docs, chunks, characters) and bar charts per document.
- The **Table View** uses **AgGrid** with **column filters** enabled.
- You can download the chunk metadata as CSV.

---

## 💬 Chat with your Data (RAG)
- Ask questions in the **Chat** tab after uploading documents.
- The app retrieves the most relevant chunks from Chroma and asks the OpenAI model to answer **grounded** in those contexts.
- It displays the **source chunks** (document name + chunk ID).

---

## 🧪 Models
- Default chat model: `gpt-4o-mini` (set via `OPENAI_MODEL`)
- Embeddings: `text-embedding-3-small` (set via `OPENAI_EMBEDDING_MODEL`)

You can change both in `.env`.

---

## 🗂 Project Structure
```
.
├── app.py
├── requirements.txt
├── .env.example
├── README.md
├── config.toml                # Streamlit theme (optional)
├── data/
│   ├── chroma/               # Chroma persistence dir (created at runtime)
│   └── uploads/              # Uploaded files (created at runtime)
└── modules/
    ├── __init__.py
    ├── auth/otp.py
    ├── rag/embeddings.py
    ├── rag/ingest.py
    ├── rag/retriever.py
    └── ui/helpers.py
```

---

## ⚙️ Environment Variables
See `.env.example` for all variables you can set.

---

## 🧯 Troubleshooting
- **OpenAI auth error**: ensure `OPENAI_API_KEY` is set in `.env` or your shell.
- **Tesseract not found**: install it and ensure it is in PATH. You can also set `pytesseract.pytesseract.tesseract_cmd` in code if needed.
- **Vector store empty**: upload documents and wait for indexing to finish.
- **CORS/Firewall for email**: if using SMTP from corporate network, ensure it’s allowed.

---

## 📄 License
MIT
