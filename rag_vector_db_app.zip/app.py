
import os
import io
import uuid
from datetime import datetime
from pathlib import Path

import streamlit as st
from streamlit_aggrid import AgGrid, GridOptionsBuilder
import pandas as pd
import numpy as np
import plotly.express as px
from dotenv import load_dotenv

from chromadb import PersistentClient

from modules.ui.helpers import inject_bootstrap, metric_card
from modules.auth.otp import OTPManager
from modules.rag.ingest import get_or_create_collection, process_and_index_files, load_chunks_df, corpus_summary
from modules.rag.retriever import retrieve_contexts, llm_answer

# =============== Init ===============
st.set_page_config(page_title="RAG Vector DB App", layout="wide")
load_dotenv()

inject_bootstrap()

PERSIST_DIR = os.getenv('PERSIST_DIR', './data/chroma')
UPLOAD_DIR = os.getenv('UPLOAD_DIR', './data/uploads')
Path(PERSIST_DIR).mkdir(parents=True, exist_ok=True)
Path(UPLOAD_DIR).mkdir(parents=True, exist_ok=True)

# Initialize Chroma
client = PersistentClient(path=PERSIST_DIR) if 'path' in PersistentClient.__init__.__code__.co_varnames else PersistentClient(persist_dir=PERSIST_DIR)
collection = get_or_create_collection(client)

# Session state
if 'auth' not in st.session_state:
    allowlist_raw = os.getenv('ALLOWED_USERS', '').strip()
    allowlist = set([e.strip().lower() for e in allowlist_raw.split(',') if e.strip()]) if allowlist_raw else None
    st.session_state.auth = {
        'logged_in': False,
        'email': None,
        'otp_mgr': OTPManager(mode=os.getenv('OTP_MODE', 'console'), ttl_seconds=300, allowlist=allowlist)
    }


# =============== Auth UI ===============

def login_ui():
    st.markdown('<div class="login-card card p-4 shadow-sm">', unsafe_allow_html=True)
    st.markdown('<h3 class="mb-3">🔐 Sign in</h3>', unsafe_allow_html=True)
    email = st.text_input('Email address', placeholder='you@example.com')
    col1, col2 = st.columns([1,1])
    with col1:
        if st.button('Send OTP', type='primary', use_container_width=True, key='send_otp'):
            if not email:
                st.error('Please enter your email')
            else:
                try:
                    st.session_state.auth['otp_mgr'].send_otp(email)
                    st.session_state.pending_email = email
                    st.success('OTP sent. Check your email or server logs (console mode).')
                except PermissionError as pe:
                    st.error(str(pe))
                except Exception as e:
                    st.error(f'Failed to send OTP: {e}')
    with col2:
        if st.button('Use Pending Email', use_container_width=True, key='use_pending'):
            if 'pending_email' in st.session_state:
                pass
            else:
                st.info('No pending email. Send OTP first.')

    otp = st.text_input('Enter OTP', max_chars=6)
    if st.button('Verify & Continue', type='primary', use_container_width=True):
        target = st.session_state.get('pending_email', email)
        if not target:
            st.error('Please enter your email and send OTP first.')
        else:
            ok = st.session_state.auth['otp_mgr'].verify(target, otp)
            if ok:
                st.session_state.auth['logged_in'] = True
                st.session_state.auth['email'] = target.lower()
                st.experimental_rerun()
            else:
                st.error('Invalid or expired OTP. Try again.')
    st.markdown('</div>', unsafe_allow_html=True)


# =============== Dashboard ===============

def dashboard_ui(user_email: str):
    st.title('📊 Dashboard')
    df = load_chunks_df(collection, user_email)
    summary = corpus_summary(df)

    m1, m2, m3 = st.columns(3)
    with m1:
        metric_card('Documents', str(summary['docs']))
    with m2:
        metric_card('Chunks', str(summary['chunks']))
    with m3:
        metric_card('Characters', f"{summary['chars']:,}")

    st.markdown('---')
    if df.empty:
        st.info('No data yet. Go to **Upload** to add documents.')
        return

    # Chart: chunks per document
    df_docs = df.groupby(['doc_id', 'filename']).agg({'id': 'count', 'chars': 'sum'}).reset_index()
    c1, c2 = st.columns(2)
    with c1:
        fig1 = px.bar(df_docs, x='filename', y='id', title='Chunks per Document', labels={'id': 'Chunks', 'filename': 'Document'})
        st.plotly_chart(fig1, use_container_width=True)
    with c2:
        fig2 = px.bar(df_docs, x='filename', y='chars', title='Characters per Document', labels={'chars': 'Characters', 'filename': 'Document'})
        st.plotly_chart(fig2, use_container_width=True)

    st.subheader('Table View (filterable)')
    g = GridOptionsBuilder.from_dataframe(df)
    g.configure_default_column(filter=True, sortable=True, resizable=True)
    g.configure_pagination(enabled=True, paginationAutoPageSize=True)
    grid_options = g.build()
    AgGrid(df, gridOptions=grid_options, height=400, fit_columns_on_grid_load=True)

    csv = df.to_csv(index=False).encode('utf-8')
    st.download_button('Download CSV', csv, file_name='chunks.csv', mime='text/csv')

    st.markdown('---')
    st.subheader('Generate Overall Summary (LLM)')
    if st.button('Generate Summary', type='primary'):
        # Use a generic summarization query and retrieve contexts
        q = 'Provide a concise, well-structured executive summary of the entire corpus.'
        hit = retrieve_contexts(collection, q, user_email, k=8)
        with st.spinner('Asking the model...'):
            stream = llm_answer(q, hit['contexts'], stream=True)
            placeholder = st.empty()
            acc = ''
            for chunk in stream:
                delta = getattr(chunk.choices[0].delta, 'content', None)
                if delta:
                    acc += delta
                    placeholder.markdown(acc)


# =============== Upload ===============

def upload_ui(user_email: str):
    st.title('📤 Upload Documents')
    files = st.file_uploader('Upload PDF, DOCX, or Image files', type=['pdf', 'docx', 'png', 'jpg', 'jpeg'], accept_multiple_files=True)
    if not files:
        st.info('You can upload multiple files at once. Max sizes depend on your Streamlit config.')
    else:
        if st.button('Process & Index', type='primary'):
            saved_paths = []
            for f in files:
                ext = Path(f.name).suffix.lower()
                fname = f"{uuid.uuid4()}{ext}"
                dest = Path(UPLOAD_DIR) / fname
                with open(dest, 'wb') as out:
                    out.write(f.getbuffer())
                saved_paths.append(str(dest))
            with st.spinner('Extracting text, chunking, embedding, and indexing...'):
                stats = process_and_index_files(collection, saved_paths, user_email)
            st.success(f"Indexed {len(saved_paths)} files → {stats['total_chunks']} chunks")

    st.markdown('---')
    st.info('Note: OCR for images requires Tesseract to be installed. If not present, OCR will be skipped with a note.')


# =============== Chat ===============

def chat_ui(user_email: str):
    st.title('💬 Chat with your Documents')
    q = st.text_input('Ask a question about your uploaded documents')
    k = st.slider('Top-K contexts', min_value=2, max_value=12, value=6)
    if st.button('Ask', type='primary'):
        if not q.strip():
            st.error('Please enter a question')
            return
        hit = retrieve_contexts(collection, q, user_email, k=k)
        contexts = hit['contexts']
        if not contexts:
            st.warning('No context found. Upload and index documents first.')
            return
        with st.spinner('Thinking...'):
            stream = llm_answer(q, contexts, stream=True)
            placeholder = st.empty()
            acc = ''
            for chunk in stream:
                delta = getattr(chunk.choices[0].delta, 'content', None)
                if delta:
                    acc += delta
                    placeholder.markdown(acc)
        st.markdown('**Sources:**')
        seen = set()
        for c in contexts:
            label = f"{c['filename']}#chunk{c['chunk_id']}"
            if label in seen:
                continue
            seen.add(label)
            st.markdown(f"<span class='source-chip'>{label}</span>", unsafe_allow_html=True)


# =============== Main ===============

def main():
    st.sidebar.title('📁 RAG App')
    if not st.session_state.auth['logged_in']:
        login_ui()
        return

    user_email = st.session_state.auth['email']
    st.sidebar.success(f"Signed in as {user_email}")
    page = st.sidebar.radio('Navigation', ['Upload', 'Dashboard', 'Chat'])

    if page == 'Upload':
        upload_ui(user_email)
    elif page == 'Dashboard':
        dashboard_ui(user_email)
    else:
        chat_ui(user_email)

    if st.sidebar.button('Sign out'):
        st.session_state.clear()
        st.experimental_rerun()


if __name__ == '__main__':
    main()
