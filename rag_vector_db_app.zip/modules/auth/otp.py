
import os
import smtplib
import random
import time
from email.mime.text import MIMEText
from typing import Optional

class OTPManager:
    def __init__(self, mode: str = "console", ttl_seconds: int = 300, allowlist: Optional[set] = None):
        self.mode = mode
        self.ttl = ttl_seconds
        self.allowlist = allowlist
        self._store = {}  # email -> (otp, expires_at)

    def _gen_code(self) -> str:
        return f"{random.randint(0, 999999):06d}"

    def _send_console(self, email: str, code: str):
        print(f"[OTP] Email: {email} | Code: {code} (valid {self.ttl//60} min)")

    def _send_smtp(self, email: str, code: str):
        server = os.getenv('SMTP_SERVER')
        port = int(os.getenv('SMTP_PORT', '587'))
        username = os.getenv('SMTP_USERNAME')
        password = os.getenv('SMTP_PASSWORD')
        from_email = os.getenv('OTP_FROM_EMAIL', username)
        if not all([server, port, username, password, from_email]):
            raise RuntimeError("SMTP settings incomplete. Check .env")
        msg = MIMEText(f"Your OTP code is: {code}
This code expires in {self.ttl//60} minutes.")
        msg['Subject'] = 'Your OTP Code'
        msg['From'] = from_email
        msg['To'] = email
        with smtplib.SMTP(server, port) as s:
            s.starttls()
            s.login(username, password)
            s.send_message(msg)

    def send_otp(self, email: str):
        if self.allowlist and email.lower() not in self.allowlist:
            raise PermissionError("This email is not authorized to sign in.")
        code = self._gen_code()
        self._store[email.lower()] = (code, time.time() + self.ttl)
        if self.mode == 'smtp':
            self._send_smtp(email, code)
        else:
            self._send_console(email, code)

    def verify(self, email: str, code: str) -> bool:
        email = email.lower()
        rec = self._store.get(email)
        if not rec:
            return False
        saved_code, expires_at = rec
        now = time.time()
        if now > expires_at:
            del self._store[email]
            return False
        if code.strip() == saved_code:
            del self._store[email]
            return True
        return False
