
import streamlit as st

def inject_bootstrap():
    bs = """
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
      .stApp {background-color: #ffffff;}
      .login-card {max-width: 480px; margin: 3rem auto;}
      .metric-card {border-radius: 10px; padding: 1rem; background: #ffffff; border: 1px solid #e5e7eb;}
      .metric-value {font-size: 1.6rem; font-weight: 700; color: #111827;}
      .metric-label {font-size: 0.9rem; color: #6b7280;}
      .source-chip {display:inline-block; padding:4px 8px; border-radius: 9999px; background:#eef2ff; color:#3730a3; margin: 0 4px 4px 0; font-size: 0.8rem;}
    </style>
    """
    st.markdown(bs, unsafe_allow_html=True)


def metric_card(label: str, value: str, help_text: str = ""):
    st.markdown(f"""
    <div class="metric-card shadow-sm">
      <div class="metric-value">{value}</div>
      <div class="metric-label">{label}</div>
      <div style="font-size: 0.8rem; color:#9ca3af;">{help_text}</div>
    </div>
    """, unsafe_allow_html=True)
