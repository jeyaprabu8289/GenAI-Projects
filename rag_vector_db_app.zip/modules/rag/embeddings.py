
import os
from typing import List
from openai import OpenAI

class OpenAIEmbedder:
    def __init__(self, model: str):
        self.model = model
        self.client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

    def embed(self, texts: List[str]) -> List[List[float]]:
        # Batches are automatically handled by OpenAI; keep it simple
        resp = self.client.embeddings.create(model=self.model, input=texts)
        return [d.embedding for d in resp.data]

# Singleton helper
_embedder = None

def get_embedder():
    global _embedder
    if _embedder is None:
        model = os.getenv('OPENAI_EMBEDDING_MODEL', 'text-embedding-3-small')
        _embedder = OpenAIEmbedder(model)
    return _embedder
