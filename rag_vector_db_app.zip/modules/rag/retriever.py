
import os
from typing import List, Dict, Any
from openai import OpenAI
from .embeddings import get_embedder


def retrieve_contexts(collection, query: str, user_id: str, k: int = 5) -> Dict:
    embedder = get_embedder()
    q_emb = embedder.embed([query])[0]
    res = collection.query(query_embeddings=[q_emb], where={'user_id': user_id}, n_results=k)
    # Normalize outputs
    ids = res.get('ids', [[]])[0]
    docs = res.get('documents', [[]])[0]
    metas = res.get('metadatas', [[]])[0]
    distances = res.get('distances', [[]])
    dists = distances[0] if distances else [None] * len(ids)
    contexts = []
    for i in range(len(ids)):
        m = metas[i]
        contexts.append({
            'id': ids[i],
            'text': docs[i],
            'filename': m.get('filename'),
            'chunk_id': m.get('chunk_id'),
            'doc_id': m.get('doc_id'),
            'distance': dists[i]
        })
    return {'query': query, 'contexts': contexts}


def build_prompt(query: str, contexts: List[Dict[str, Any]]) -> str:
    header = (
        "You are a helpful assistant. Answer the user's question strictly based on the provided CONTEXT. "
        "If the answer is not in the context, say you don't know. Cite sources by filename and chunk id."
    )
    ctx_lines = []
    for i, c in enumerate(contexts, 1):
        src = f"{c.get('filename','unknown')}#chunk{c.get('chunk_id')}"
        ctx_lines.append(f"[Source {i}: {src}]
{c['text']}")
    context_block = "

".join(ctx_lines)
    prompt = f"""
{header}

CONTEXT:
{context_block}

QUESTION: {query}

Return a concise, well-structured answer with bullet points if helpful, and a final line: Sources: <comma-separated source labels>.
"""
    return prompt.strip()


def llm_answer(query: str, contexts: List[Dict], stream: bool = True) -> Any:
    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
    prompt = build_prompt(query, contexts)
    if stream:
        return client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            stream=True,
        )
    else:
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return resp.choices[0].message.content
