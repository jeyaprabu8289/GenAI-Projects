
import os
import io
import uuid
import pdfplumber
from PIL import Image
import pytesseract
import docx2txt
from docx import Document
from typing import List, Dict, Tuple
from datetime import datetime

import pandas as pd

from chromadb import PersistentClient
from chromadb.utils import embedding_functions

from .embeddings import get_embedder

SUPPORTED_IMG = {'.png', '.jpg', '.jpeg'}


def _read_pdf(path: str) -> str:
    texts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            t = page.extract_text() or ''
            texts.append(t)
    return "
".join(texts)


def _read_docx(path: str) -> str:
    try:
        return docx2txt.process(path) or ''
    except Exception:
        # Fallback to python-docx if docx2txt fails
        doc = Document(path)
        return "
".join([p.text for p in doc.paragraphs])


def _read_image(path: str) -> str:
    try:
        img = Image.open(path)
        text = pytesseract.image_to_string(img)
        return text or ''
    except Exception as e:
        return f"[OCR unavailable: {e}]"


def load_file_text(path: str) -> Tuple[str, Dict]:
    """Return (text, metadata) for a given file path."""
    ext = os.path.splitext(path)[1].lower()
    name = os.path.basename(path)
    if ext == '.pdf':
        text = _read_pdf(path)
    elif ext == '.docx':
        text = _read_docx(path)
    elif ext in SUPPORTED_IMG:
        text = _read_image(path)
    else:
        raise ValueError(f"Unsupported file type: {ext}")
    meta = {
        'filename': name,
        'ext': ext,
        'path': path,
    }
    return text, meta


def chunk_text(text: str, chunk_size: int = 1500, overlap: int = 300) -> List[str]:
    text = text.replace('', '')
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + chunk_size, n)
        chunk = text[start:end]
        chunks.append(chunk)
        if end == n:
            break
        start = end - overlap
        if start < 0:
            start = 0
    return [c.strip() for c in chunks if c.strip()]


def get_or_create_collection(client: PersistentClient, name: str = 'rag_docs'):
    # Use default cosine distance
    try:
        col = client.get_or_create_collection(name=name)
    except TypeError:
        # Older/newer API signature guard
        col = client.get_or_create_collection(name)
    return col


def process_and_index_files(collection, filepaths: List[str], user_id: str) -> Dict:
    """Extract text, chunk, embed, and add to Chroma collection."""
    embedder = get_embedder()
    total_chunks = 0
    added_ids = []
    per_doc = []

    for path in filepaths:
        text, base_meta = load_file_text(path)
        doc_id = str(uuid.uuid4())
        chunks = chunk_text(text)
        if not chunks:
            continue
        embeddings = embedder.embed(chunks)
        ids = [f"{doc_id}:{i}" for i in range(len(chunks))]
        ts = datetime.utcnow().isoformat()
        metadatas = [{
            'doc_id': doc_id,
            'chunk_id': i,
            'user_id': user_id,
            'filename': base_meta['filename'],
            'ext': base_meta['ext'],
            'path': base_meta['path'],
            'created_at': ts,
            'chars': len(chunks[i])
        } for i in range(len(chunks))]
        collection.add(ids=ids, documents=chunks, metadatas=metadatas, embeddings=embeddings)
        total_chunks += len(chunks)
        added_ids.extend(ids)
        per_doc.append({'doc_id': doc_id, 'filename': base_meta['filename'], 'chunks': len(chunks), 'chars': sum(m['chars'] for m in metadatas)})

    return {
        'total_chunks': total_chunks,
        'ids': added_ids,
        'docs': per_doc,
    }


def load_chunks_df(collection, user_id: str) -> pd.DataFrame:
    results = collection.get(where={'user_id': user_id})
    ids = results.get('ids', [])
    docs = results.get('documents', [])
    metas = results.get('metadatas', [])
    rows = []
    for i in range(len(ids)):
        m = metas[i]
        rows.append({
            'id': ids[i],
            'doc_id': m.get('doc_id'),
            'chunk_id': m.get('chunk_id'),
            'filename': m.get('filename'),
            'ext': m.get('ext'),
            'chars': m.get('chars'),
            'created_at': m.get('created_at'),
            'preview': (docs[i][:200] + '...') if docs[i] and len(docs[i]) > 200 else docs[i],
        })
    df = pd.DataFrame(rows)
    if not df.empty:
        df['created_at'] = pd.to_datetime(df['created_at'])
    return df


def corpus_summary(df: pd.DataFrame) -> Dict:
    if df.empty:
        return {'docs': 0, 'chunks': 0, 'chars': 0}
    docs = df['doc_id'].nunique()
    chunks = len(df)
    chars = int(df['chars'].fillna(0).sum())
    return {'docs': docs, 'chunks': chunks, 'chars': chars}
