from typing import List, Tuple
import os
import openai
from transformers import pipeline

class RCAAgent:
    def __init__(self, vector_store, model_choice: str = "OpenAI (recommended)"):
        self.vs = vector_store
        self.model_choice = model_choice
        self.openai_key = os.environ.get("OPENAI_API_KEY")
        if self.openai_key:
            openai.api_key = self.openai_key

    def _call_llm(self, prompt: str) -> str:
        if self.openai_key and 'OpenAI' in self.model_choice:
            resp = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[{"role":"user","content":prompt}],
                temperature=0.2,
                max_tokens=500,
            )
            return resp['choices'][0]['message']['content'].strip()
        else:
            # fallback local generator (small) — simple and limited
            gen = pipeline('text-generation', model='gpt2')
            out = gen(prompt, max_length=200, do_sample=True, num_return_sequences=1)
            return out[0]['generated_text']

    def answer(self, question: str, top_k: int = 4) -> Tuple[str, List[str]]:
        evidence = self.vs.query(question, top_k=top_k)
        context = "\n\n---\n\n".join(evidence)
        prompt = (
            f"You are an incident response assistant for banking production systems. "
            f"Use the following retrieved context from logs and incident notes to answer the question precisely.\n\n"
            f"Context:\n{context}\n\nQuestion: {question}\n\nAnswer concisely and include the confidence level (low/medium/high) and summary of reasoning."
        )
        answer = self._call_llm(prompt)
        return answer, evidence

    def generate_incident_summary(self) -> dict:
        # use a broad query to retrieve many chunks
        chunks = self.vs.query("incident summary", top_k=8)
        context = "\n\n".join(chunks)
        prompt = (
            f"You are an incident response assistant. Given the following context from logs and incident notes:\n{context}\n\n"
            "Produce a JSON object with keys: summary (short paragraph), root_causes (list of top 3 likely root causes), next_steps (a list of recommended next steps for engineers). Be concise."
        )
        raw = self._call_llm(prompt)
        # Try to robustly parse simple JSON — if not parseable return raw text
        import json
        try:
            parsed = json.loads(raw)
            return parsed
        except Exception:
            return {"summary": raw, "root_causes": [], "next_steps": []}