from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import pandas as pd
from pathlib import Path

EMBED_MODEL = "all-MiniLM-L6-v2"

class FaissVectorStore:
    def __init__(self, index_path: Path, meta_path: Path):
        self.index_path = Path(index_path)
        self.meta_path = Path(meta_path)
        self.model = SentenceTransformer(EMBED_MODEL)
        self.dim = self.model.get_sentence_embedding_dimension()
        self._load()

    def _load(self):
        if self.index_path.exists() and self.meta_path.exists():
            self.index = faiss.read_index(str(self.index_path))
            self.metadata = pd.read_parquet(self.meta_path)
        else:
            self.index = faiss.IndexFlatIP(self.dim)
            self.metadata = pd.DataFrame(columns=["text"])

    def save(self):
        faiss.write_index(self.index, str(self.index_path))
        self.metadata.to_parquet(self.meta_path)

    def add_texts(self, texts: list):
        emb = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=True)
        # normalize for cosine similarity
        faiss.normalize_L2(emb)
        if isinstance(self.index, faiss.IndexFlatIP):
            # need to recreate a larger index with ids if multiple adds - simple approach: append
            if self.index.ntotal == 0:
                self.index.add(emb)
            else:
                self.index.add(emb)
        else:
            self.index.add(emb)
        df = pd.DataFrame({"text": texts})
        self.metadata = pd.concat([self.metadata, df], ignore_index=True)
        self.save()

    def query(self, q: str, top_k: int = 4):
        q_emb = self.model.encode([q], convert_to_numpy=True)
        faiss.normalize_L2(q_emb)
        D, I = self.index.search(q_emb, top_k)
        results = []
        for idx in I[0]:
            if idx < len(self.metadata):
                results.append(self.metadata.iloc[idx]["text"])
        return results