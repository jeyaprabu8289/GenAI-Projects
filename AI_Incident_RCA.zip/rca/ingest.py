import io
from typing import List
from sentence_transformers import SentenceTransformer
from pathlib import Path
import pdfplumber
import docx

EMBED_MODEL = "all-MiniLM-L6-v2"

def extract_text_from_file(filename: str, data: bytes) -> str:
    lower = filename.lower()
    if lower.endswith('.txt') or lower.endswith('.log'):
        return data.decode('utf-8', errors='replace')
    elif lower.endswith('.pdf'):
        text = ''
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            for page in pdf.pages:
                text += '\n' + page.extract_text() or ''
        return text
    elif lower.endswith('.docx') or lower.endswith('.doc'):
        doc = docx.Document(io.BytesIO(data))
        return '\n'.join(p.text for p in doc.paragraphs)
    else:
        return data.decode('utf-8', errors='replace')


def chunk_text(text: str, chunk_size: int = 800, overlap: int = 100) -> List[str]:
    tokens = text.split()
    chunks = []
    i = 0
    n = len(tokens)
    while i < n:
        chunk = tokens[i:i+chunk_size]
        chunks.append(' '.join(chunk))
        i += chunk_size - overlap
    return chunks