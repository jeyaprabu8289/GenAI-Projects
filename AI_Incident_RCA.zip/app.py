from pathlib import Path
import streamlit as st
from rca.ingest import extract_text_from_file, chunk_text
from rca.vectorstore import FaissVectorStore
from rca.agent import RCAAgent
import os

st.set_page_config(page_title="AI Incident RCA", layout="wide")

st.title("AI-Powered Incident Root Cause Analysis")

with st.sidebar:
    st.header("Index / Ingest")
    uploaded_files = st.file_uploader("Upload logs or incident docs (txt, pdf, docx)", accept_multiple_files=True)
    paste_logs = st.text_area("Or paste logs here (optional)", height=150)
    index_button = st.button("Ingest & Index")
    st.markdown("---")
    st.header("Settings")
    model_choice = st.selectbox("LLM Backend", ["OpenAI (recommended)", "Local fallback (small)"])
    top_k = st.slider("Top-K retrieval", min_value=1, max_value=10, value=4)

# workspace
WORKDIR = Path(".rca_data")
WORKDIR.mkdir(exist_ok=True)
index_path = WORKDIR / "faiss.index"
meta_path = WORKDIR / "metadata.parquet"

vector_store = FaissVectorStore(index_path, meta_path)
agent = RCAAgent(vector_store=vector_store, model_choice=model_choice)

if index_button:
    all_texts = []
    # from uploaded files
    for f in uploaded_files:
        bytes_data = f.read()
        text = extract_text_from_file(f.name, bytes_data)
        chunks = chunk_text(text)
        all_texts.extend(chunks)
    # from pasted logs
    if paste_logs and paste_logs.strip():
        all_texts.extend(chunk_text(paste_logs))

    if not all_texts:
        st.warning("No text found to ingest. Upload a file or paste logs.")
    else:
        with st.spinner("Embedding and indexing... this may take a minute for lots of text"):
            vector_store.add_texts(all_texts)
        st.success(f"Indexed {len(all_texts)} text chunks.")

st.markdown("---")

st.header("Query the Incident")
query = st.text_input("Ask a question about the incident (e.g. 'root cause?', 'which services failed?')")
if st.button("Run Query") and query.strip():
    with st.spinner("Retrieving relevant context and generating answer..."):
        answer, evidence = agent.answer(query, top_k=top_k)
    st.subheader("Answer")
    st.write(answer)
    st.subheader("Evidence (top retrieved chunks)")
    for i, e in enumerate(evidence, 1):
        st.markdown(f"**{i}.** {e[:1000]}")

st.markdown("---")

st.header("Incident Summary / RCA")
if st.button("Generate Incident Summary"):
    with st.spinner("Generating summary and recommended next steps..."):
        summary = agent.generate_incident_summary()
    st.subheader("Summary")
    st.write(summary.get("summary"))
    st.subheader("Likely Root Causes")
    for rc in summary.get("root_causes", []):
        st.write(f"- {rc}")
    st.subheader("Recommended Next Steps")
    for step in summary.get("next_steps", []):
        st.write(f"- {step}")

st.markdown("---")
st.info("Sample logs are available in sample_data/logs.txt — try ingesting that first to see functionality.")