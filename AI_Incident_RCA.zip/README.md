# AI-Powered Incident RCA (Streamlit)


## Overview
A local Streamlit app that:
- Ingests logs and incident documents (txt, pdf, docx)
- Extracts text, embeds with sentence-transformers
- Indexes with FAISS
- Answers analyst questions using retrieved context + an LLM (OpenAI by default, fallback to local transformer)
- Produces an incident summary, likely root causes, and recommended next steps


## Requirements
- Python 3.9 or 3.10 (3.11 may also work)
- OS: Linux, macOS or Windows


## Installation
1. Clone or copy project files into a folder.
2. Create a virtual environment and activate it:


```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows (powershell)
.\.venv\Scripts\Activate.ps1